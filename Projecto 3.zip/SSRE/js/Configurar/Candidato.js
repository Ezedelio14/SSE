const url = sessionStorage.getItem("url");

class Candidato {
  constructor() {
    this.nome = document.getElementById("nome").value;
    this.data_nascimento = document.getElementById("data-nascimento").value;
    this.bi = document.getElementById("bi").value;
    document.querySelectorAll(".gender").forEach((gendero, index) => {
      if (gendero.checked) {
        this.gender = index == 0 ? "Homem" : "Mulher";
      }
    });
    this.nif = document.getElementById("nif").value;
    this.partido = document.getElementById("partido").value;
    this.phone = document.getElementById("phone").value;
    this.email = document.getElementById("email").value;
    this.profissao = document.getElementById("profissao").value;
  }

  validarInput() {
    let value = true;
    if (this.nome == "") value = false;
    if (this.data_nascimento == "") value = false;
    if (this.bi == "") value = false;
    if (this.nif == "") value = false;
    if (this.partido == "") value = false;
    if (this.phone == "") value = false;
    if (this.email == "") value = false;
    if (this.profissao == "") value = false;
    return value;
  }

  removerCandidato(id) {
    fetch(`${url}/${id}`, {
      method: "DELETE",
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error("Não foi possível remover o Candidato");
        }
        alert("Candidato removido com sucesso");
      })
      .catch((error) => {
        alert("Erro ao remover Candidato:", error);
      });
  }

  updateCandidato(dados, id) {
    const options = {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(dados),
    };

    fetch(`${url}/${id}`, options)
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
      })
      .catch((error) => {
        console.error(error);
      });
  }

  editarCandidato(
    id,
    nome,
    data_nascimento,
    bi,
    gender,
    nif,
    partido,
    profissao
  ) {
    const form = document.createElement("form");
    const container = document.createElement("div");
    const div = document.createElement("div");
    const inputName = document.createElement("input");
    const inputdata = document.createElement("input");
    const inputBI = document.createElement("input");
    const inputNif = document.createElement("input");
    const inputGenero = document.createElement("input");
    const inputPartido = document.createElement("input");
    const inputProfissao = document.createElement("input");
    const editBtn = document.createElement("input");
    const cancelarBtn = document.createElement("input");

    inputName.placeholder = "Nome";
    inputName.type = "text";
    inputdata.type = "date";
    inputBI.placeholder = "BI";
    inputBI.type = "text";
    inputNif.placeholder = "Nif";
    inputNif.type = "text";
    inputGenero.placeholder = "Genero";
    inputGenero.type = "text";
    inputPartido.placeholder = "Partido";
    inputPartido.type = "text";
    inputProfissao.placeholder = "Profissão";
    inputProfissao.type = "text";

    inputName.value = nome;
    inputdata.value = data_nascimento;
    inputBI.value = bi;
    inputNif.value = gender;
    inputGenero.value = nif;
    inputPartido.value = partido;
    inputProfissao.value = profissao;

    editBtn.value = "Editar";
    cancelarBtn.value = "Cancelar";
    editBtn.type = "submit";
    cancelarBtn.type = "submit";

    form.setAttribute("class", "formEdit");
    form.appendChild(inputName);
    form.appendChild(inputdata);
    form.appendChild(inputBI);
    form.appendChild(inputNif);
    form.appendChild(inputGenero);
    form.appendChild(inputPartido);
    form.appendChild(inputProfissao);
    form.appendChild(editBtn);
    form.appendChild(cancelarBtn);
    div.appendChild(editBtn);
    div.appendChild(cancelarBtn);
    form.appendChild(div);
    container.appendChild(form);
    container.setAttribute("class", "containerEdit");
    document.querySelector(".container>div").appendChild(container);
    editBtn.addEventListener("click", (e) => {
      e.preventDefault();
      this.updateCandidato(
        {
          nome: inputName.value,
          data_nascimento: inputdata.value,
          bi: inputBI.value,
          gender: inputNif.value,
          nif: inputGenero.value,
          partido: inputPartido.value,
          profissao: inputProfissao.value,
        },
        id
      );
    });
  }

  async setCandidatoBD() {
    const candidato = {
      votos: 0,
      status: false,
      nome: this.nome,
      data_nascimento: this.data_nascimento,
      bi: this.bi,
      gender: this.gender,
      nif: this.nif,
      partido: this.partido,
      phone: this.phone,
      email: this.email,
      profissao: this.profissao,
    };
    console.log(candidato);
    const response = await fetch(url, {
      method: "POST",
      body: JSON.stringify(candidato),
      headers: {
        "Content-Type": "application/json",
      },
    }).then((resp) => {
      if (resp.ok) {
        alert("Cadastro feito com sucesso!");
      } else {
        alert("Falha no cadastro!");
      }
    });
  }

  async getCandidatosBD() {
    const response = await fetch(url);
    const data = await response.json();
    const lista = document.querySelector("#lista-candidatos > table");

    const idade = (data) => {
      let dataNas = data.split("-");
      let dataA = new Date();
      let dataAtual = dataA.toLocaleDateString().split("/");
      if (
        parseInt(dataAtual[1]) >= parseInt(dataNas[1]) &&
        parseInt(dataAtual[0]) >= parseInt(dataNas[2])
      ) {
        return parseInt(dataAtual[2]) - parseInt(dataNas[0]);
      }
      return parseInt(dataAtual[2]) - parseInt(dataNas[0]) - 1;
    };

    data.forEach((element) => {
      const tr = document.createElement("tr");
      const nome = document.createElement("td");
      const age = document.createElement("td");
      const bi = document.createElement("td");
      const nif = document.createElement("td");
      const gender = document.createElement("td");
      const partido = document.createElement("td");
      const profissao = document.createElement("td");
      const editCandidato = document.createElement("td");
      const removeBtn = document.createElement("button");
      const editarBtn = document.createElement("button");

      removeBtn.innerText = "remover";
      editarBtn.innerText = "editar";

      editCandidato.appendChild(editarBtn);
      removeBtn.addEventListener("click", () => {
        this.removerCandidato(element.id);
      });

      editarBtn.addEventListener("click", () => {
        this.editarCandidato(
          element.id,
          element.nome,
          element.data_nascimento,
          element.bi,
          element.gender,
          element.nif,
          element.partido,
          element.profissao
        );
      });

      editCandidato.appendChild(removeBtn);
      editCandidato.setAttribute("class", "edit");

      nome.innerText = `${element.nome}`;
      tr.appendChild(nome);

      age.innerText = `${idade(element.data_nascimento)}`;
      tr.appendChild(age);

      bi.innerText = `${element.bi}`;
      tr.appendChild(bi);

      nif.innerText = `${element.nif}`;
      tr.appendChild(nif);

      partido.innerText = `${element.partido}`;
      tr.appendChild(partido);

      profissao.innerText = `${element.profissao}`;
      tr.appendChild(profissao);

      gender.innerText = `${element.gender}`;
      tr.appendChild(gender);

      tr.appendChild(editCandidato);

      lista.appendChild(tr);
    });
  }
}

export default Candidato;
