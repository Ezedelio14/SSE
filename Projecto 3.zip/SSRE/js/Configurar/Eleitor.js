const url = "http://localhost:3000/eleitor";

export class Eleitor {
  constructor() {
    this.nome = document.getElementById("nome").value;
    this.data_nascimento = document.getElementById("data-nascimento").value;
    this.bi = document.getElementById("bi").value;
    document.querySelectorAll(".gender").forEach((gendero, index) => {
      if (gendero.checked) {
        this.gender = index == 0 ? "Homem" : "Mulher";
      }
    });
    this.nif = document.getElementById("nif").value;
  }

  validarInput() {
    let value = true;
    if (this.nome == "") value = false;
    if (this.data_nascimento == "") value = false;
    if (this.bi == "") value = false;
    if (this.nif == "") value = false;
    return value;
  }

  removerEleitor(id) {
    fetch(`${url}/${id}`, {
      method: "DELETE",
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error("Não foi possível remover o Eleitor");
        }
        alert("Eleitor removido com sucesso");
      })
      .catch((error) => {
        console.error("Erro ao remover o elemento:", error);
      });
  }

  updateEleitor(dados, id) {
    const options = {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(dados),
    };

    fetch(`${url}/${id}`, options)
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
      })
      .catch((error) => {
        console.error(error);
      });
  }

  editarEleitor(id, nome, data_nascimento, bi, gender, nif) {
    const form = document.createElement("form");
    const container = document.createElement("div");
    const div = document.createElement("div");
    const inputName = document.createElement("input");
    const inputdata = document.createElement("input");
    const inputBI = document.createElement("input");
    const inputNif = document.createElement("input");
    const inputGenero = document.createElement("input");
    const editBtn = document.createElement("input");
    const cancelarBtn = document.createElement("input");

    inputName.placeholder = "Nome";
    inputName.type = "text";
    inputdata.type = "date";
    inputBI.placeholder = "BI";
    inputBI.type = "text";
    inputNif.placeholder = "Nif";
    inputNif.type = "text";
    inputGenero.placeholder = "Genero";
    inputGenero.type = "text";

    inputName.value = nome;
    inputdata.value = data_nascimento;
    inputBI.value = bi;
    inputNif.value = gender;
    inputGenero.value = nif;

    editBtn.value = "Editar";
    cancelarBtn.value = "Cancelar";
    editBtn.type = "submit";
    cancelarBtn.type = "submit";

    form.setAttribute("class", "formEdit");
    form.appendChild(inputName);
    form.appendChild(inputdata);
    form.appendChild(inputBI);
    form.appendChild(inputNif);
    form.appendChild(inputGenero);
    form.appendChild(editBtn);
    form.appendChild(cancelarBtn);
    div.appendChild(editBtn);
    div.appendChild(cancelarBtn);
    form.appendChild(div);
    container.appendChild(form);
    container.setAttribute("class", "containerEdit");
    document.querySelector(".container>div").appendChild(container);
    editBtn.addEventListener("click", (e) => {
      e.preventDefault();
      this.updateEleitor(
        {
          nome: inputName.value,
          data_nascimento: inputdata.value,
          bi: inputBI.value,
          gender: inputNif.value,
          nif: inputGenero.value,
        },
        id
      );
    });
  }

  async setEleitorBD() {
    const eleitor = {
      presidencial: false,
      parlamentar: false,
      municipal: false,
      nome: this.nome,
      data_nascimento: this.data_nascimento,
      bi: this.bi,
      gender: this.gender,
      nif: this.nif,
    };

    const response = await fetch(url, {
      method: "POST",
      body: JSON.stringify(eleitor),
      headers: {
        "Content-Type": "application/json",
      },
    }).then((resp) => {
      if (resp.ok) {
        alert("Cadastro feito com sucesso!");
      } else {
        alert("Falha no cadastro!");
      }
    });
  }

  async getEleitoresBD() {
    const response = await fetch(url);
    const data = await response.json();
    const lista = document.querySelector("#lista-eleitores > table");
    const idade = (data) => {
      let dataNas = data.split("-");
      let dataA = new Date();
      let dataAtual = dataA.toLocaleDateString().split("/");
      if (
        parseInt(dataAtual[1]) >= parseInt(dataNas[1]) &&
        parseInt(dataAtual[0]) >= parseInt(dataNas[2])
      ) {
        return parseInt(dataAtual[2]) - parseInt(dataNas[0]);
      }
      return parseInt(dataAtual[2]) - parseInt(dataNas[0]) - 1;
    };

    data.forEach((element) => {
      const tr = document.createElement("tr");
      const nome = document.createElement("td");
      const age = document.createElement("td");
      const bi = document.createElement("td");
      const nif = document.createElement("td");
      const gender = document.createElement("td");
      const editCandidato = document.createElement("td");
      const removeBtn = document.createElement("button");
      const editarBtn = document.createElement("button");

      removeBtn.innerText = "remover";
      editarBtn.innerText = "editar";

      editCandidato.appendChild(editarBtn);
      editCandidato.appendChild(removeBtn);
      editCandidato.setAttribute("class", "edit");

      removeBtn.addEventListener("click", () => {
        this.removerEleitor(element.id);
      });

      editarBtn.addEventListener("click", () => {
        this.editarEleitor(
          element.id,
          element.nome,
          element.data_nascimento,
          element.bi,
          element.gender,
          element.nif
        );
      });

      nome.innerText = `${element.nome}`;
      tr.appendChild(nome);
      age.innerText = `${idade(element.data_nascimento)}`;
      tr.appendChild(age);
      bi.innerText = `${element.bi}`;
      tr.appendChild(bi);
      nif.innerText = `${element.nif}`;
      tr.appendChild(nif);
      gender.innerText = `${element.gender}`;
      tr.appendChild(gender);

      tr.appendChild(editCandidato);

      lista.appendChild(tr);
    });
  }
}

export default Eleitor;
