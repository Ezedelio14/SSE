const menu = document.querySelectorAll("#lista-processos li");
const btn_declararVencedor = document.querySelectorAll(".btnDecVencedor");
const btn_cancelar = document.querySelectorAll(".btnCancelar");

document.querySelectorAll(".container div").forEach((tabela) => {
  tabela.style.display = "none";
});

btn_cancelar.forEach((button, index) => {
  button.style.display = "none";
});

document.getElementById("first").classList.add("active");
document.getElementById(`tabela1`).style.display = "block";

menu.forEach((option, index) => {
  option.addEventListener("click", () => {
    option.classList.add("active");
    document.getElementById(`tabela${index + 1}`).style.display = "block";
    menu.forEach((menuOption, index) => {
      if (option.textContent != menuOption.textContent) {
        menuOption.classList.remove("active");
        document.getElementById(`tabela${index + 1}`).style.display = "none";
      }
    });
  });
});

btn_declararVencedor.forEach((button, index) => {
  button.addEventListener("click", () => {
    const showVencedor = document.getElementById(`vencedor${index + 1}`);
    showVencedor.style.display = "flex";
    button.style.display = "none";
    btn_cancelar[index].style.display = "block";
  });
});

btn_cancelar.forEach((button, index) => {
  button.addEventListener("click", () => {
    const showVencedor = document.getElementById(`vencedor${index + 1}`);
    showVencedor.style.display = "none";
    button.style.display = "none";
    btn_declararVencedor[index].style.display = "block";
  });
});
